# Changelog

## v0.2

- Added shared SuperModuleShell
- Added configurable Home, Planning and Journal previews
- Added working capacity, density and depth controls
- Added FloatingDock component
- Low-capacity mode now reduces visible content
- Added first P3 Kanban visual reference
- Added first calm journal writing surface

# Mockup Catalog

Alla mockups ska få ett unikt ID och en status.

## Statusar

- `reference` — aktiv visuell referens
- `candidate` — utvärderas
- `merged` — idéer införlivade i annan variant
- `archived` — ska inte styra ny design

| ID | Modul | Variant | Status | Styrka | Risk |
|---|---|---|---|---|---|
| HOME-001 | Home | Executive Midnight | reference | Tydligt ankare och dagssteg | Kan bli dashboardtung |
| PLAN-001 | Planning | Calm P3 | candidate | Professionell kanban | Kräver lågkapacitetsläge |
| JOURNAL-001 | Journal | Writing Focus | candidate | Lugn reflektion | Får inte likna Valv |

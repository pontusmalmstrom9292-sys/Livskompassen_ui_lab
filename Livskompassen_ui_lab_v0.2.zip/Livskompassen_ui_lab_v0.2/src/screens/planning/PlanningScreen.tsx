import { Plus } from 'lucide-react';
import { ActionButton } from '@/design-system/components/ActionButton';
import { CalmCard } from '@/design-system/components/CalmCard';
import type { CapacityMode, DensityMode, DepthMode } from '@/design-system/tokens';
import { SuperModuleShell } from '@/supermodules/core/SuperModuleShell';
import { FloatingDock } from '@/components/FloatingDock';

const columns = [
  {
    title: 'Att göra',
    items: ['Förbered möte', 'Köp present', 'Träna 20 min'],
  },
  {
    title: 'Väntar',
    items: ['Svar från banken', 'Offert från leverantör'],
  },
  {
    title: 'Klart',
    items: ['Morgon check-in', 'Skicka rapport'],
  },
];

type PlanningScreenProps = {
  capacity: CapacityMode;
  density: DensityMode;
  depth: DepthMode;
};

export function PlanningScreen({ capacity, density, depth }: PlanningScreenProps) {
  const low = capacity === 'low';

  return (
    <SuperModuleShell
      title="Planering"
      eyebrow="Vardagen"
      density={density}
      depth={depth}
    >
      <CalmCard className="module-card">
        <p className="text-xs uppercase tracking-[0.18em] text-text-muted">Nästa steg</p>
        <h2 className="mt-2 text-xl font-semibold">Förbered mötet med Anna</h2>
        <p className="mt-2 text-sm text-text-secondary">Ett steg i taget. Resten kan vänta.</p>
      </CalmCard>

      {!low && (
        <section className="grid grid-cols-3 gap-2" aria-label="P3 Kanban">
          {columns.map((column) => (
            <CalmCard key={column.title} className="module-card !p-3">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-xs font-semibold uppercase tracking-[0.12em]">{column.title}</h2>
                <span className="text-xs text-text-muted">{column.items.length}</span>
              </div>
              <div className="space-y-2">
                {column.items.map((item) => (
                  <article
                    key={item}
                    className="rounded-control border border-line-subtle bg-surface-1 p-3 text-xs leading-5"
                  >
                    {item}
                  </article>
                ))}
              </div>
            </CalmCard>
          ))}
        </section>
      )}

      <ActionButton className="w-full">
        <Plus className="mr-2 inline" size={18} />
        Ny uppgift
      </ActionButton>

      <FloatingDock active="everyday" />
    </SuperModuleShell>
  );
}

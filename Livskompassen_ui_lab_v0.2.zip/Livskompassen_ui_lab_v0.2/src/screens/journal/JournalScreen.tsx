import { BookOpenText, PenLine } from 'lucide-react';
import { ActionButton } from '@/design-system/components/ActionButton';
import { CalmCard } from '@/design-system/components/CalmCard';
import type { CapacityMode, DensityMode, DepthMode } from '@/design-system/tokens';
import { SuperModuleShell } from '@/supermodules/core/SuperModuleShell';
import { FloatingDock } from '@/components/FloatingDock';

type JournalScreenProps = {
  capacity: CapacityMode;
  density: DensityMode;
  depth: DepthMode;
};

export function JournalScreen({ capacity, density, depth }: JournalScreenProps) {
  const low = capacity === 'low';

  return (
    <SuperModuleShell
      title="Dagbok"
      eyebrow="Hjärtat"
      density={density}
      depth={depth}
    >
      {!low && (
        <CalmCard className="module-card" depth="instrument">
          <p className="text-xs uppercase tracking-[0.18em] text-accent">Dagens reflektion</p>
          <p className="mt-3 font-display text-2xl">Vad behöver få lämna huvudet idag?</p>
          <p className="mt-3 text-sm leading-6 text-text-secondary">
            Skriv fritt. Ingenting behöver bli perfekt eller färdigt.
          </p>
        </CalmCard>
      )}

      <CalmCard className="module-card">
        <label htmlFor="journal-entry" className="flex items-center gap-2 text-sm font-semibold">
          <PenLine size={18} className="text-accent" />
          Skrivyta
        </label>
        <textarea
          id="journal-entry"
          rows={8}
          placeholder="Skriv det som finns inom dig..."
          className="mt-4 w-full resize-none rounded-control border border-line-subtle bg-surface-1 p-4 text-sm leading-6 text-text-primary outline-none placeholder:text-text-muted focus:border-accent/55 focus:ring-2 focus:ring-accent/25"
        />
        <ActionButton className="mt-4 w-full">Spara reflektion</ActionButton>
      </CalmCard>

      {!low && (
        <CalmCard className="module-card">
          <div className="mb-4 flex items-center gap-2">
            <BookOpenText size={18} className="text-accent" />
            <h2 className="font-semibold">Senaste inlägg</h2>
          </div>
          <ul className="divide-y divide-line-subtle">
            {['Tacksam för lugnet', 'Kvällspromenaden', 'Ett svårt samtal'].map((entry) => (
              <li key={entry} className="flex min-h-12 items-center justify-between py-3 text-sm">
                <span>{entry}</span>
                <span className="text-xs text-text-muted">›</span>
              </li>
            ))}
          </ul>
        </CalmCard>
      )}

      <FloatingDock active="home" />
    </SuperModuleShell>
  );
}

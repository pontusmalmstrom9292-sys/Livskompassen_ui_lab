import { Mic, NotebookPen, Sparkles } from 'lucide-react';
import { ActionButton } from '@/design-system/components/ActionButton';
import { CalmCard } from '@/design-system/components/CalmCard';
import type { CapacityMode, DensityMode, DepthMode } from '@/design-system/tokens';
import { homeMock } from '@/mock-data/home';
import { SuperModuleShell } from '@/supermodules/core/SuperModuleShell';
import { FloatingDock } from '@/components/FloatingDock';

type HomeScreenProps = {
  capacity: CapacityMode;
  density: DensityMode;
  depth: DepthMode;
};

export function HomeScreen({ capacity, density, depth }: HomeScreenProps) {
  const low = capacity === 'low';

  return (
    <SuperModuleShell
      title={`God morgon, ${homeMock.userName}`}
      eyebrow="Den Trygga Hamnen"
      density={density}
      depth={depth}
    >
      <CalmCard className="module-card" depth={depth}>
        <p className="text-xs uppercase tracking-[0.18em] text-accent">Dagens ankare</p>
        <p className="mt-3 font-display text-2xl">{homeMock.anchor}</p>
      </CalmCard>

      <CalmCard className="module-card">
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.18em] text-text-muted">Nästa mikrosteg</p>
            <h2 className="mt-2 text-xl font-semibold">{homeMock.nextStep}</h2>
          </div>
          <div className="grid size-14 place-items-center rounded-full border border-line-strong bg-surface-3 text-accent shadow-inset">
            <Sparkles aria-hidden="true" size={22} />
          </div>
        </div>
      </CalmCard>

      {!low && (
        <CalmCard className="module-card">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold">Dagens steg</h2>
            <span className="text-sm text-text-muted">{homeMock.steps.length} steg</span>
          </div>
          <ul className="divide-y divide-line-subtle">
            {homeMock.steps.map((step) => (
              <li key={step.id} className="flex min-h-12 items-center gap-3 py-3">
                <span className="size-5 rounded-md border border-accent/55" aria-hidden="true" />
                <span className="flex-1 text-sm">{step.label}</span>
                <time className="text-xs text-text-muted">{step.time}</time>
              </li>
            ))}
          </ul>
        </CalmCard>
      )}

      <section aria-labelledby="quick-actions-title">
        <h2 id="quick-actions-title" className="mb-3 text-xs uppercase tracking-[0.18em] text-text-muted">
          Snabbstart
        </h2>
        <div className="grid grid-cols-3 gap-3">
          <ActionButton variant="secondary" className="flex flex-col items-center gap-2">
            <NotebookPen size={20} />
            Anteckning
          </ActionButton>
          <ActionButton variant="secondary" className="flex flex-col items-center gap-2">
            <Mic size={20} />
            Inspelning
          </ActionButton>
          <ActionButton variant="secondary" className="flex flex-col items-center gap-2">
            <Sparkles size={20} />
            Inkast
          </ActionButton>
        </div>
      </section>

      {!low && (
        <CalmCard className="module-card">
          <div className="flex items-end justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.18em] text-text-muted">Kapacitet idag</p>
              <p className="mt-2 font-display text-4xl text-accent">{homeMock.capacity}/10</p>
              <p className="mt-1 text-sm text-text-secondary">Stabil</p>
            </div>
            <div className="h-12 w-28 rounded-full border border-line-subtle bg-surface-1 p-1">
              <div
                className="h-full rounded-full bg-accent/75"
                style={{ width: `${homeMock.capacity * 10}%` }}
                aria-label={`Kapacitet ${homeMock.capacity} av 10`}
              />
            </div>
          </div>
        </CalmCard>
      )}

      <FloatingDock active="home" />
    </SuperModuleShell>
  );
}

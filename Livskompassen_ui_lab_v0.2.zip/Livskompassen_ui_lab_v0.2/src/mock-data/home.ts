export const homeMock = {
  userName: 'Pontus',
  anchor: 'Ett mikrosteg räcker.',
  nextStep: 'Fixa packning',
  capacity: 7,
  steps: [
    { id: '1', label: 'Fixa packning', time: '09:30', done: false },
    { id: '2', label: 'Ring Anna', time: '11:30', done: false },
    { id: '3', label: 'Träna 20 min', time: '18:00', done: false },
  ],
};

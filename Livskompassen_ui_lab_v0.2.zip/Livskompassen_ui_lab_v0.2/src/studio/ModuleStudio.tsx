import { useMemo, useState } from 'react';
import { HomeScreen } from '@/screens/home/HomeScreen';
import { JournalScreen } from '@/screens/journal/JournalScreen';
import { PlanningScreen } from '@/screens/planning/PlanningScreen';
import type { CapacityMode, DensityMode, DepthMode } from '@/design-system/tokens';

type ModuleId = 'home' | 'planning' | 'journal';

export function ModuleStudio() {
  const [moduleId, setModuleId] = useState<ModuleId>('home');
  const [capacity, setCapacity] = useState<CapacityMode>('normal');
  const [density, setDensity] = useState<DensityMode>('calm');
  const [depth, setDepth] = useState<DepthMode>('soft-3d');

  const status = useMemo(
    () => `${moduleId} · ${capacity} · ${density} · ${depth}`,
    [moduleId, capacity, density, depth],
  );

  const preview = {
    home: <HomeScreen capacity={capacity} density={density} depth={depth} />,
    planning: <PlanningScreen capacity={capacity} density={density} depth={depth} />,
    journal: <JournalScreen capacity={capacity} density={density} depth={depth} />,
  }[moduleId];

  return (
    <div className="min-h-screen bg-[#040910] text-text-primary lg:grid lg:grid-cols-[320px_1fr]">
      <aside className="border-b border-line-subtle bg-surface-1 p-5 lg:min-h-screen lg:border-b-0 lg:border-r">
        <p className="text-xs uppercase tracking-[0.22em] text-accent">Supermodule Studio</p>
        <h1 className="mt-2 font-display text-3xl">Livskompassen UI Lab</h1>
        <p className="mt-3 text-sm leading-6 text-text-secondary">
          Växla modul, kapacitetsläge, täthet och visuellt djup i realtid.
        </p>

        <div className="mt-7 space-y-5">
          <ControlGroup
            label="Modul"
            value={moduleId}
            options={['home', 'planning', 'journal']}
            onChange={(value) => setModuleId(value as ModuleId)}
          />
          <ControlGroup
            label="Kapacitet"
            value={capacity}
            options={['low', 'normal', 'high']}
            onChange={(value) => setCapacity(value as CapacityMode)}
          />
          <ControlGroup
            label="Täthet"
            value={density}
            options={['calm', 'balanced', 'full']}
            onChange={(value) => setDensity(value as DensityMode)}
          />
          <ControlGroup
            label="Djup"
            value={depth}
            options={['flat', 'soft-3d', 'instrument']}
            onChange={(value) => setDepth(value as DepthMode)}
          />
        </div>

        <p className="mt-8 rounded-control border border-line-subtle bg-surface-2 p-3 text-xs text-text-muted">
          {status}
        </p>
      </aside>

      <main className="overflow-auto p-4 sm:p-8">
        <div className="mx-auto w-fit overflow-hidden rounded-[38px] border border-line-strong bg-canvas shadow-floating">
          <div className="h-[820px] w-[390px] overflow-y-auto">{preview}</div>
        </div>
      </main>
    </div>
  );
}

type ControlGroupProps = {
  label: string;
  value: string;
  options: string[];
  onChange: (value: string) => void;
};

function ControlGroup({ label, value, options, onChange }: ControlGroupProps) {
  return (
    <fieldset>
      <legend className="mb-2 text-sm font-semibold">{label}</legend>
      <div className="grid gap-2">
        {options.map((option) => (
          <button
            key={option}
            onClick={() => onChange(option)}
            className={[
              'min-h-12 rounded-control border px-3 text-left text-sm capitalize',
              option === value
                ? 'border-accent/55 bg-accent/10 text-accent'
                : 'border-line-subtle bg-surface-2 text-text-secondary',
            ].join(' ')}
          >
            {option}
          </button>
        ))}
      </div>
    </fieldset>
  );
}

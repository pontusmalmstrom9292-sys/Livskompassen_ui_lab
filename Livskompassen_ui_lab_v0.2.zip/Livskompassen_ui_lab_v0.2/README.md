# Livskompassen UI Lab

Ett helt fristående frontend- och designlaboratorium för Livskompassen 3.0.

## Syfte

Här testas designsystem, navigation, supermoduler, visuella varianter och kognitiv belastning innan något övervägs för produktionsappen.

## Absolut isoleringsregel

This repository must never import files from `Livskompassen3.0`.

Firebase, backend, produktions-stores, API:er och verklig användardata är förbjudna. Endast typad mockdata får användas.

## Start

```bash
npm install
npm run dev
```

## Verifiering

```bash
npm run typecheck
npm run build
```

## Innehåll

- `docs/` — Design Bible, UI-lagar, modulregister och beslut
- `src/design-system/` — tokens och primitiver
- `src/supermodules/` — konfigurerbara supermoduler
- `src/studio/` — live-preview och inställningar
- `src/screens/` — referensskärmar
- `src/mock-data/` — typad mockdata

## Current prototype

v0.2 includes configurable Home, Planning and Journal supermodule previews.
